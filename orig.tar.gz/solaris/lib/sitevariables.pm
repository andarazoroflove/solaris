package svb;
	
our $title = 'things i&apos;ve learned about Solaris...';
our $templatefile = 'template.html';
our $post_template = 'post_template.html';
our $htmlpath = 'http://solaris.andarazoroflove.org';
our $htmlsystempath = '/homepages/21/d99922209/htdocs/arol/solaris/';
our $scriptpath = 'http://solaris.andarazoroflove.org';
our $textmax = '3000';
our $page = '4';
our $timetoadd = '-3';
our $cssfile = 'http://solaris.andarazoroflove.org/blogdata/blog.css';
our $subscriptions = 'yes';
our $webmaster = 'adam@wooble.org';
our $sendmail = '/usr/lib/sendmail -i -t';
our $maxpicsize = '10000000';
our $full_width = '600';
our $picalign = 'right';
our $preview_width = '250';
our $use_imagemagick = 'no';
our $rsslang = 'en-us';
our $rsslink = 'http://solaris.andarazoroflove.org/index.cgi';
our $rssdescription = 'things i&apos;ve learned about Solaris...';
our $rssrights = '(c)1999-2k5 andarazoroflove multimedia';
our $rsstextmax = '500';
our $rssmaxentries = '10';

return 1;